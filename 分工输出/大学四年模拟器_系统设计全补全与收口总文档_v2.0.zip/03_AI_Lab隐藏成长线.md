# AI-Lab隐藏成长线与真实战场规则

包含： - HIDDEN - FORESHADOW - DISCOVERED - ACTIVE - CORE

五阶段生命周期。

同时包含： - AI-Lab进入条件 - 真实战场规则 - 三路线赋能机制 -
非AI-Lab玩家保障
