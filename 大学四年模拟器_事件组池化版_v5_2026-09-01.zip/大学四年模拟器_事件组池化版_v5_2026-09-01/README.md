# 《大学四年模拟器》事件组池化版 v5

> 保留原10个事件组和520个事件，只修正月内选择、即时解锁、依序关系、文案时间冲突与隐藏内容发布边界。

- 事件总数：520
- 事件组：10
- 每组事件：{'AC': 52, 'AI': 52, 'FA': 52, 'GE': 52, 'HE': 52, 'PU': 52, 'RE': 52, 'RO': 52, 'SO': 52, 'WK': 52}
- 同组每月事件上限：无；由TU与EP决定。
- 选择后：立即结算并在同月重新计算可见池。

## 接入文件

- `data/player/`：可进入客户端的普通事件文案，不含特殊路线。
- `engine/events_pool_internal.json`：服务端完整事件池和依序关系。
- `engine/event_groups_internal.json`：事件组开启规则。
- `engine/game_loop_rules.json`：月内多事件与即时重算规则。
- `engine/hidden_event_payloads.json`：只在条件满足后由服务端下发。
- `ops/events_pool_internal.md`：策划可读全量事件卡。
- `specs/event_pool_schema_v5.json`：池化事件结构约束。
- `specs/事件组池运行规则.md`：可见、可选和月内即时重算规则。
- `reports/validation_report.md`：数量、关系、时间和泄露校验。

## 发布边界

客户端不得包含 `engine/` 和 `ops/`。特殊路线不能依靠前端改名隐藏，必须由服务端在事件组开启后逐条返回。
