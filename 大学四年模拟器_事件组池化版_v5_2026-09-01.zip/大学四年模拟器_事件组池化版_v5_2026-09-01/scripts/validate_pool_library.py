#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EVENTS_PATH = ROOT / "engine" / "events_pool_internal.json"
GROUPS_PATH = ROOT / "engine" / "event_groups_internal.json"
LOOP_PATH = ROOT / "engine" / "game_loop_rules.json"
PUBLIC_DIR = ROOT / "data" / "player"

PERSON_TOKENS = (
    "阿航", "李老师", "周宁", "林栩", "赵野", "吴老师", "老何", "许安",
    "唐棠", "沈夏", "梁晨", "秦川", "高工", "笑与泪",
)

GENERIC_COPY = (
    "眼前最具体的变化是", "新的现实问题随之浮现", "本月需要处理的新情况是",
    "事情由此推进到", "摆在你面前的事实可以概括为", "局面的下一步是",
    "校园日常出现了一处具体变化", "原有节奏被一件具体事情打断",
    "前一次尝试留下了可见反馈", "外部反馈已经足够明确",
)

STAGE_WINDOWS = {
    "大一上": (1, 5), "大一下": (6, 10), "大一": (1, 10),
    "大二上": (11, 15), "大二下": (16, 20), "大二": (11, 20),
    "大三上": (21, 25), "大三下": (26, 30), "大三": (21, 30),
    "大四上": (31, 36), "大四下": (37, 42), "大四": (31, 42),
    "新生报到": (1, 6), "毕业典礼": (40, 42),
}


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def text_fields(event: dict) -> str:
    option_text = " ".join(option["text"] for option in event["options"])
    return " ".join((event["title"], event["context"], event["conflict"], option_text))


def normalize(text: str) -> str:
    return re.sub(r"[^\u4e00-\u9fffA-Za-z0-9]", "", text)


def validate(events: list[dict], groups: list[dict], loop_rules: dict) -> tuple[list[str], list[str], dict]:
    errors = []
    warnings = []
    ids = [event["event_id"] for event in events]
    by_id = {event["event_id"]: event for event in events}
    if len(ids) != len(set(ids)):
        errors.append("event_id不唯一")

    group_counts = Counter(event["group"] for event in events)
    if len(group_counts) != 10:
        errors.append(f"事件组数量不是10：{len(group_counts)}")
    if len(set(group_counts.values())) != 1:
        errors.append(f"各事件组数量不均衡：{dict(group_counts)}")

    group_ids = {group["event_group_id"] for group in groups}
    if group_ids != set(group_counts):
        errors.append("事件组定义与事件数据不一致")
    if any(group["monthly_event_limit"] is not None for group in groups):
        errors.append("仍存在事件组月度次数上限")
    if loop_rules.get("event_group_monthly_limit") is not None:
        errors.append("回合规则错误地限制了同组月度事件数")
    if not loop_rules.get("same_month_unlock"):
        errors.append("未开启月内即时解锁")

    produced_flags = {
        flag
        for event in events
        for option in event["options"]
        for flag in option["add_flags"]
    }
    required_flags = {flag for event in events for flag in event["required_flags"]}
    missing_flags = sorted(required_flags - produced_flags)
    if missing_flags:
        errors.append(f"前置Flag无来源：{missing_flags}")
    for group in groups:
        missing_group_flags = sorted(set(group.get("unlock_any_flags", [])) - produced_flags)
        if missing_group_flags:
            errors.append(f"{group['event_group_id']}事件组开启Flag无来源：{missing_group_flags}")
        if group.get("hidden_until_open") and not group.get("unlock_any_flags"):
            errors.append(f"{group['event_group_id']}隐藏事件组没有过程入口")

    sequence_edges = 0
    same_month_edges = 0
    by_chain = defaultdict(list)
    for event in events:
        by_chain[event["chain_id"]].append(event)
        if not 1 <= event["earliest_visible_month"] <= event["latest_valid_month"] <= 42:
            errors.append(f"{event['event_id']}时间窗非法")
        previous_ids = event["sequence"]["predecessor_event_ids"]
        if event["chain_step"] == 1 and previous_ids:
            errors.append(f"{event['event_id']}入口事件不应有前置")
        if event["chain_step"] > 1 and len(previous_ids) != 1:
            errors.append(f"{event['event_id']}依序关系缺失")
        for previous_id in previous_ids:
            sequence_edges += 1
            previous = by_id.get(previous_id)
            if not previous:
                errors.append(f"{event['event_id']}前置事件不存在：{previous_id}")
                continue
            if previous["group"] != event["group"] or previous["chain_id"] != event["chain_id"]:
                errors.append(f"{event['event_id']}前置跨越错误事件组或子链")
            if previous["latest_valid_month"] >= event["earliest_visible_month"]:
                same_month_edges += 1
            previous_flags = {flag for option in previous["options"] for flag in option["add_flags"]}
            if not previous_flags.intersection(event["required_flags"]):
                errors.append(f"{event['event_id']}没有读取前置事件结果")
            predecessor_unlocks = {target for option in previous["options"] for target in option.get("unlocks_event_ids", [])}
            if event["event_id"] not in predecessor_unlocks:
                errors.append(f"{event['event_id']}未被前置事件标注为即时开启目标")

        for option in event["options"]:
            if option["cost"]["TU"] < 0 or option["cost"]["EP"] < 0:
                errors.append(f"{event['event_id']}/{option['option_id']}资源消耗为负")
            if option.get("future_events"):
                errors.append(f"{event['event_id']}仍使用延迟future_events")
            for target_id in option.get("unlocks_event_ids", []):
                if target_id not in by_id:
                    errors.append(f"{event['event_id']}开启不存在事件：{target_id}")

    impossible_chains = []
    for chain_id, chain_events in by_chain.items():
        ordered = sorted(chain_events, key=lambda item: item["chain_step"])
        if [event["chain_step"] for event in ordered] != [1, 2, 3, 4]:
            errors.append(f"{chain_id}节点编号异常")
            continue
        month = 0
        for event in ordered:
            month = max(month, event["earliest_visible_month"])
            if month > event["latest_valid_month"]:
                impossible_chains.append(chain_id)
                break
    if impossible_chains:
        errors.append(f"即使允许月内连续选择仍不可完成的子链：{impossible_chains}")

    titles = [event["title"] for event in events]
    contexts = [event["context"] for event in events]
    if len(titles) != len(set(titles)):
        errors.append("存在重复事件标题")
    if len(contexts) != len(set(contexts)):
        errors.append("存在完全重复背景")
    for event in events:
        if normalize(event["title"]) in normalize(event["context"]):
            errors.append(f"{event['event_id']}背景复述标题")
        if re.search(r"第\d+(?:至第\d+)?月", event["context"]):
            errors.append(f"{event['event_id']}背景仍硬编码回合月份")
        for token in GENERIC_COPY:
            if token in event["context"]:
                errors.append(f"{event['event_id']}背景残留模板语句：{token}")
        combined = text_fields(event)
        found_names = [token for token in PERSON_TOKENS if token in combined]
        if found_names:
            errors.append(f"{event['event_id']}出现人名：{found_names}")

        for term, (stage_min, stage_max) in STAGE_WINDOWS.items():
            if term in combined:
                if event["latest_valid_month"] < stage_min or event["earliest_visible_month"] > stage_max:
                    errors.append(
                        f"{event['event_id']}文案阶段“{term}”与M{event['earliest_visible_month']}-M{event['latest_valid_month']}冲突"
                    )
                break

    normalized_contexts = [(event["event_id"], normalize(event["context"])) for event in events]
    similar_pairs = []
    for index, (left_id, left) in enumerate(normalized_contexts):
        for right_id, right in normalized_contexts[index + 1:]:
            ratio = SequenceMatcher(None, left, right).ratio()
            if ratio >= 0.92:
                similar_pairs.append((left_id, right_id, round(ratio, 3)))
    if similar_pairs:
        errors.append(f"存在高相似背景：{similar_pairs[:10]}")

    public_text = "\n".join(path.read_text(encoding="utf-8") for path in PUBLIC_DIR.glob("*.json"))
    forbidden_public = ("AI_", "FLAG_", "MSG_", "required_flags", "unlocks_event_ids", "未命名协作", "AI-Lab")
    for token in forbidden_public:
        if token in public_text:
            errors.append(f"玩家端泄露特殊路线或内部字段：{token}")
    public_events = load(PUBLIC_DIR / "events_public.json")
    if len(public_events) != len(events) - group_counts["AI"]:
        errors.append("玩家端普通事件数量不正确")
    expected_public_ids = [f"EVT_{index:04d}" for index in range(1, len(public_events) + 1)]
    if [event["public_id"] for event in public_events] != expected_public_ids:
        errors.append("玩家端事件编号不连续")

    density = defaultdict(dict)
    for group_id in sorted(group_counts):
        for month in range(1, 43):
            density[group_id][month] = sum(
                event["group"] == group_id
                and event["earliest_visible_month"] <= month <= event["latest_valid_month"]
                for event in events
            )
    peak_density = {
        group_id: {"count": max(months.values()), "months": [month for month, count in months.items() if count == max(months.values())]}
        for group_id, months in density.items()
    }

    metrics = {
        "events": len(events),
        "groups": len(group_counts),
        "subchains": len(by_chain),
        "events_per_group": dict(sorted(group_counts.items())),
        "sequence_edges": sequence_edges,
        "same_month_progression_edges": same_month_edges,
        "public_events": len(public_events),
        "server_only_events": group_counts["AI"],
        "high_similarity_context_pairs": len(similar_pairs),
        "peak_raw_visibility_by_group": peak_density,
    }
    return errors, warnings, metrics


def write_report(errors: list[str], warnings: list[str], metrics: dict) -> None:
    lines = [
        "# 事件组池化版验收报告",
        "",
        "## 规则确认",
        "",
        "- 同一月份可以处理同一事件组内的多个事件。",
        "- 玩家也可以在同月跨事件组处理事件。",
        "- 每次选择后立即结算资源、状态与Flag，并在同月重新计算可见池。",
        "- 事件数量只受当月TU、EP和玩家主动结束月份限制，不设置事件组月度次数上限。",
        "",
        "## 数据指标",
        "",
        f"- 事件总数：{metrics['events']}",
        f"- 事件组：{metrics['groups']}",
        f"- 组内子链：{metrics['subchains']}",
        f"- 每组事件：{metrics['events_per_group']}",
        f"- 必要依序关系：{metrics['sequence_edges']}",
        f"- 可在同月继续推进的关系：{metrics['same_month_progression_edges']}",
        f"- 客户端普通事件：{metrics['public_events']}",
        f"- 服务端条件下发事件：{metrics['server_only_events']}",
        "",
        "## 校验结果",
        "",
    ]
    if errors:
        lines.append(f"- 未通过：{len(errors)}项错误。")
        lines.extend(f"  - {error}" for error in errors)
    else:
        lines.extend([
            "- 通过：依序关系在允许月内连续选择时均可达。",
            "- 通过：所有背景无硬编码回合月份、无标题复述、无人名、无高相似文本。",
            "- 通过：大学阶段词与事件时间窗无冲突。",
            "- 通过：玩家端不包含特殊路线、内部Flag和完整依序图。",
        ])
    if warnings:
        lines.extend(["", "## 提醒", ""])
        lines.extend(f"- {warning}" for warning in warnings)
    lines.extend(["", "## 各组单月原始可见峰值", ""])
    for group_id, item in metrics["peak_raw_visibility_by_group"].items():
        months = ", ".join(f"M{month}" for month in item["months"])
        lines.append(f"- {group_id}：{item['count']}个（{months}）")
    lines.extend([
        "",
        "> 峰值按月份窗口统计，尚未扣除前置Flag；实际可见数会更低。这里不设置候选池截断，玩家可浏览事件组内全部可见事件。",
        "",
    ])
    (ROOT / "reports").mkdir(parents=True, exist_ok=True)
    (ROOT / "reports" / "validation_report.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    events = load(EVENTS_PATH)
    groups = load(GROUPS_PATH)
    loop_rules = load(LOOP_PATH)
    errors, warnings, metrics = validate(events, groups, loop_rules)
    write_report(errors, warnings, metrics)
    print(json.dumps({"errors": errors, "warnings": warnings, "metrics": metrics}, ensure_ascii=False, indent=2))
    raise SystemExit(1 if errors else 0)


if __name__ == "__main__":
    main()
