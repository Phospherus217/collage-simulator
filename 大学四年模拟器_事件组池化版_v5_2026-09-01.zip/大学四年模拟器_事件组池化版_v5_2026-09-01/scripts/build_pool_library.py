#!/usr/bin/env python3
from __future__ import annotations

import copy
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source" / "events_generated_v2.json"

GROUP_CONFIG = {
    "PU": {"name": "公共/通识生活", "open_month": 1},
    "AC": {"name": "学业与专业课", "open_month": 1},
    "SO": {"name": "校园社交与竞赛", "open_month": 1},
    "FA": {"name": "家庭与突发经济", "open_month": 1},
    "HE": {"name": "身心健康与作息", "open_month": 1},
    "RO": {"name": "恋爱与情感", "open_month": 4},
    "RE": {"name": "保研推免", "open_month": 8},
    "WK": {"name": "求职与就业", "open_month": 10},
    "GE": {"name": "考研", "open_month": 18},
    "AI": {
        "name": "内部特殊路线",
        "open_month": 2,
        "hidden": True,
        "unlock_any_flags": [
            "FLAG_SO_CH03_S1_DONE",
            "FLAG_AC_CH03_S1_DONE",
            "FLAG_AC_CH13_S1_DONE",
        ],
    },
}

PERSON_REPLACEMENTS = {
    "室友阿航": "一位室友",
    "辅导员李老师": "辅导员",
    "宿管阿姨": "宿管老师",
    "班长周宁": "班长",
    "高数老师陈老师": "任课老师",
    "助教林栩": "课程助教",
    "同组队友赵野": "同组同学",
    "实验课老师吴老师": "实验课老师",
    "社团学长老何": "社团学长",
    "外院同学许安": "外院同学",
    "校友师姐唐棠": "一位校友",
    "同班同学沈夏": "同班同学",
    "朋友许安": "一位朋友",
    "社团同学林栩": "社团同学",
    "跑步搭子许安": "运动伙伴",
    "实习导师高工": "实习导师",
    "HR姐姐": "招聘人员",
    "项目经理秦川": "项目经理",
    "研友梁晨": "备考伙伴",
    "目标院校学长": "目标院校学生",
    "导师陈老师": "课题导师",
    "保研师姐唐棠": "保研学姐",
    "课题组博士师兄": "课题组成员",
    "助教学长老何": "助教学长",
    "核心骨干笑与泪": "项目骨干",
    "产品师姐唐棠": "产品负责人",
    "实验室负责人": "项目负责人",
}

COPY_REPLACEMENTS = {
    "AI-Lab浅层线索": "一条尚未公开的协作线索",
    "AI-Lab第一张试水任务卡": "第一张未署名试水任务卡",
    "AI-Lab核心团队邀请与阶段晋升": "一次没有公开报名的阶段邀请",
    "AI-Lab与考研/保研/秋招冲突": "深度协作与考研、保研、秋招冲突",
    "AI-Lab和考研、保研、秋招难以兼顾": "深度协作和考研、保研、秋招难以兼顾",
    "AI-Lab隐藏路线": "未命名协作路线",
    "AI-Lab": "未命名协作",
}

CONTEXT_OVERRIDES = {
    "PU_0302": "办事大厅的取号屏不断跳号，材料被退回后，你才发现不同窗口要求的字段和附件并不通用。",
    "SO_0403": "活动策划案反复改版，例会不断延长，原本留给课程和休息的时间被临时通知切得越来越碎。",
    "HE_0203": "连续几周没有按计划训练，天气和课程只是表面原因，真正消失的是为运动预留的固定时段。",
    "RO_0502": "早已约定的安排临近时，课程项目和考试同时进入关键阶段，双方都在等待对方先给出取舍。",
    "RE_1201": "几位导师都给出进一步交流机会，但指导方式、研究议题和团队氛围呈现出完全不同的组合。",
    "FA_1002": "几个毕业选项摆到桌面后，讨论逐渐集中在城市距离、职业稳定和未来照顾家庭的现实成本上。",
    "WK_1002": "几份机会被列进对比表后，身边重要的人分别从收入、城市和共同生活出发给出不同判断。",
    "AC_1003": "距离最终检查越来越近，实验缺口、论文结构和演示稳定性同时暴露，留给返工的时间已经无法平均分配。",
    "SO_1003": "毕业去向陆续确定，曾经随时能见面的同学开始被不同城市、作息和下一阶段目标重新排列。",
}

GENERIC_PROGRESS = (
    "原本只是背景信息的变化，已经具体到需要你在本月作出反应。",
    "这件事没有立刻造成损失，却悄悄打开了一条新的行动路径。",
    "你手里的信息还不完整，但继续忽略会错过最自然的进入时机。",
    "当下并不要求马上押上全部精力，只要求你判断它是否值得跟进。",
    "前一次尝试留下了可见反馈，接下来需要更稳定的投入才能继续。",
    "事情从体验阶段转入实际执行，细节开始决定结果能走多远。",
    "最初的新鲜感已经过去，持续推进需要方法、时间和外部反馈。",
    "已有进展证明方向并非空想，同时也暴露出下一步最现实的障碍。",
    "两个都重要的安排撞在同一时间窗里，任何取舍都会留下明确代价。",
    "此前积累的问题在截止日期前集中显现，继续硬撑已不再是中性选择。",
    "资源只够保住一部分目标，你必须决定牺牲上限、速度还是个人边界。",
    "局面已经无法靠拖延自行消失，沟通、加码和止损分别通向不同后果。",
    "几轮选择的结果逐渐稳定下来，这段经历将以某种方式进入后续生活。",
    "事情终于来到收口阶段，留下的是成果、习惯、关系变化或一次清晰教训。",
    "外部反馈已经足够明确，现在要判断哪些部分值得保留，哪些应当结束。",
    "临时压力退去后，真正重要的是这次经历是否改变了下一阶段的做法。",
)


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def replace_text(text: str) -> str:
    for source, target in PERSON_REPLACEMENTS.items():
        text = text.replace(source, target)
    for source, target in COPY_REPLACEMENTS.items():
        text = text.replace(source, target)
    return text


def clean_context(text: str) -> str:
    text = replace_text(text)
    for sentence in GENERIC_PROGRESS:
        text = text.replace(sentence, "")
    text = re.sub(r"。时间来到第\d+(?:至第\d+)?月，本月需要处理的新情况是：", "。", text)
    text = re.sub(r"。进入第\d+(?:至第\d+)?月后，局面的下一步是：", "。", text)
    text = re.sub(r"到了第\d+(?:至第\d+)?月，", "", text)
    text = re.sub(r"第\d+(?:至第\d+)?月，校园日常出现了一处具体变化：", "", text)
    text = re.sub(r"第\d+(?:至第\d+)?月，原有节奏被一件具体事情打断：", "", text)
    text = re.sub(r"第\d+(?:至第\d+)?月，", "", text)
    transitions = {
        "眼前最具体的变化是：": "",
        "；新的现实问题随之浮现：": "。",
        "事情由此推进到：": "",
        "摆在你面前的事实可以概括为：": "",
        "这次变化指向：": "",
        "接下来的行动将围绕一个现实变化展开：": "",
    }
    for source, target in transitions.items():
        text = text.replace(source, target)
    text = re.sub(r"。{2,}", "。", text)
    return text.strip("；。 ") + "。"


def transform_strings(value):
    if isinstance(value, str):
        return replace_text(value)
    if isinstance(value, list):
        return [transform_strings(item) for item in value]
    if isinstance(value, dict):
        return {key: transform_strings(item) for key, item in value.items()}
    return value


def hidden_category(event: dict) -> str:
    chain_no = int(event["chain_id"][-2:])
    return "未署名任务" if 5 <= chain_no <= 10 else "课程与项目"


def build_events(source_events: list[dict]) -> tuple[list[dict], dict[str, str]]:
    events = transform_strings(copy.deepcopy(source_events))
    by_task = {event["event_task_id"]: event["event_id"] for event in events}
    by_chain = defaultdict(list)
    for event in events:
        by_chain[event["chain_id"]].append(event)

    predecessor = {}
    for chain_events in by_chain.values():
        ordered = sorted(chain_events, key=lambda item: item["chain_step"])
        for previous, current in zip(ordered, ordered[1:]):
            predecessor[current["event_id"]] = previous["event_id"]

    public_id_map = {}
    ordinary_index = 0
    hidden_index = 0
    for event in events:
        event["context"] = CONTEXT_OVERRIDES.get(event["event_id"], clean_context(event["context"]))
        event["pool_version"] = 5
        event["event_group_id"] = event["group"]
        event["availability"] = {
            "earliest_visible_month": event["earliest_visible_month"],
            "latest_valid_month": event["latest_valid_month"],
            "required_flags": event["required_flags"],
            "forbidden_flags": event["forbidden_flags"],
            "required_state": event["required_state"],
        }
        previous_id = predecessor.get(event["event_id"])
        event["sequence"] = {
            "relation": "REQUIRES_PREVIOUS" if previous_id else "ENTRY",
            "predecessor_event_ids": [previous_id] if previous_id else [],
            "same_month_progression_allowed": True,
        }
        for option in event["options"]:
            unlocks = []
            for future in option.get("future_events", []):
                target_id = by_task.get(future.get("event_task_id"))
                if target_id:
                    unlocks.append(target_id)
            option["unlocks_event_ids"] = unlocks
            option["future_events"] = []

        if event["group"] == "AI":
            event["player_category"] = hidden_category(event)
        else:
            event["player_category"] = event["group_name"]

    events.sort(key=lambda item: (item["earliest_visible_month"], item["group"], item["chain_id"], item["chain_step"]))
    for event in events:
        if event["group"] == "AI":
            hidden_index += 1
            public_id = f"MSG_{hidden_index:03d}"
        else:
            ordinary_index += 1
            public_id = f"EVT_{ordinary_index:04d}"
        event["public_id"] = public_id
        public_id_map[public_id] = event["event_id"]
    return events, public_id_map


def player_payload(event: dict) -> dict:
    return {
        "public_id": event["public_id"],
        "display_category": event["player_category"],
        "visible_months": [event["earliest_visible_month"], event["latest_valid_month"]],
        "title": event["title"],
        "context": event["context"],
        "conflict": event["conflict"],
        "options": [
            {
                "option_key": option["option_id"],
                "text": option["text"],
                "load_label": option["ui_load_label"],
                "cost": option["cost"],
            }
            for option in event["options"]
        ],
    }


def build_groups() -> list[dict]:
    groups = []
    for group_id, config in GROUP_CONFIG.items():
        groups.append({
            "event_group_id": group_id,
            "internal_name": config["name"],
            "initial_state": "LOCKED" if config.get("hidden") else "OPEN_AT_MONTH",
            "open_month": config["open_month"],
            "hidden_until_open": bool(config.get("hidden")),
            "unlock_any_flags": config.get("unlock_any_flags", []),
            "monthly_event_limit": None,
            "selection_rule": "MULTIPLE_EVENTS_WHILE_RESOURCES_ALLOW",
        })
    return groups


def build_loop_rules() -> dict:
    return {
        "months": 42,
        "turn_unit": "MONTH",
        "event_group_monthly_limit": None,
        "selection_cycle": [
            "REFRESH_RESOURCES",
            "OPEN_ELIGIBLE_GROUPS",
            "COMPUTE_VISIBLE_EVENTS",
            "PLAYER_SELECTS_EVENT_AND_OPTION",
            "APPLY_COST_EFFECTS_AND_FLAGS_IMMEDIATELY",
            "RECOMPUTE_VISIBLE_EVENTS_IN_SAME_MONTH",
            "CONTINUE_UNTIL_PLAYER_ENDS_MONTH_OR_NO_OPTION_IS_AFFORDABLE",
        ],
        "event_visibility": [
            "GROUP_IS_OPEN",
            "CURRENT_MONTH_IN_EVENT_WINDOW",
            "REQUIRED_FLAGS_AND_STATE_MATCH",
            "EVENT_NOT_COMPLETED",
        ],
        "option_selectability": [
            "EVENT_IS_VISIBLE",
            "CURRENT_TU_AT_LEAST_OPTION_TU",
            "CURRENT_EP_AT_LEAST_OPTION_EP",
        ],
        "same_month_unlock": True,
        "resource_values": "由游戏主程序配置；事件库只声明每个选项的TU与EP消耗。",
    }


def event_to_md(event: dict) -> str:
    sequence = event["sequence"]
    lines = [
        f"### {event['public_id']}｜{event['title']}",
        "",
        f"- 内部ID：{event['event_id']}｜事件组：{event['group']}｜子链：{event['chain_id']} / {event['chain_step']}",
        f"- 时间窗：M{event['earliest_visible_month']}–M{event['latest_valid_month']}",
        f"- 依序关系：{sequence['relation']}｜前置：{', '.join(sequence['predecessor_event_ids']) or '无'}",
        f"- 必须Flag：{', '.join(event['required_flags']) or '无'}",
        "",
        f"**背景：** {event['context']}",
        "",
        f"**矛盾：** {event['conflict']}",
        "",
        "**选项：**",
        "",
    ]
    for option in event["options"]:
        lines.extend([
            f"- [{option['option_id']}] {option['text']}",
            f"  - 消耗：{option['cost']['TU']} TU / {option['cost']['EP']} EP",
            f"  - 即时开启：{', '.join(option['unlocks_event_ids']) or '无'}",
            "",
        ])
    return "\n".join(lines)


def main() -> None:
    source_events = load(SOURCE)
    events, public_id_map = build_events(source_events)
    groups = build_groups()
    ordinary = [player_payload(event) for event in events if event["group"] != "AI"]
    hidden = [player_payload(event) for event in events if event["group"] == "AI"]

    write_json(ROOT / "engine" / "events_pool_internal.json", events)
    write_json(ROOT / "engine" / "event_groups_internal.json", groups)
    write_json(ROOT / "engine" / "game_loop_rules.json", build_loop_rules())
    write_json(ROOT / "engine" / "hidden_event_payloads.json", hidden)
    write_json(ROOT / "engine" / "public_id_map.json", public_id_map)
    write_json(ROOT / "data" / "player" / "events_public.json", ordinary)
    write_json(ROOT / "data" / "player" / "event_groups_public.json", [
        {"event_group_id": group["event_group_id"], "name": GROUP_CONFIG[group["event_group_id"]]["name"], "open_month": group["open_month"]}
        for group in groups if not group["hidden_until_open"]
    ])

    by_group = Counter(event["group"] for event in events)
    readme = [
        "# 《大学四年模拟器》事件组池化版 v5",
        "",
        "> 保留原10个事件组和520个事件，只修正月内选择、即时解锁、依序关系、文案时间冲突与隐藏内容发布边界。",
        "",
        f"- 事件总数：{len(events)}",
        f"- 事件组：{len(groups)}",
        f"- 每组事件：{dict(sorted(by_group.items()))}",
        "- 同组每月事件上限：无；由TU与EP决定。",
        "- 选择后：立即结算并在同月重新计算可见池。",
        "",
        "## 接入文件",
        "",
        "- `data/player/`：可进入客户端的普通事件文案，不含特殊路线。",
        "- `engine/events_pool_internal.json`：服务端完整事件池和依序关系。",
        "- `engine/event_groups_internal.json`：事件组开启规则。",
        "- `engine/game_loop_rules.json`：月内多事件与即时重算规则。",
        "- `engine/hidden_event_payloads.json`：只在条件满足后由服务端下发。",
        "- `ops/events_pool_internal.md`：策划可读全量事件卡。",
        "- `specs/event_pool_schema_v5.json`：池化事件结构约束。",
        "- `specs/事件组池运行规则.md`：可见、可选和月内即时重算规则。",
        "- `reports/validation_report.md`：数量、关系、时间和泄露校验。",
        "",
        "## 发布边界",
        "",
        "客户端不得包含 `engine/` 和 `ops/`。特殊路线不能依靠前端改名隐藏，必须由服务端在事件组开启后逐条返回。",
        "",
    ]
    (ROOT / "README.md").write_text("\n".join(readme), encoding="utf-8")

    md = ["# 事件组池化版｜内部全量事件卡", ""]
    for event in events:
        md.append(event_to_md(event))
    (ROOT / "ops").mkdir(parents=True, exist_ok=True)
    (ROOT / "ops" / "events_pool_internal.md").write_text("\n".join(md), encoding="utf-8")


if __name__ == "__main__":
    main()
